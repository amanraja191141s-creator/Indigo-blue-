# SA Calculator v98.44 — Premium Tools Menu

- Replaced the always-visible in-content search row with a collapsed-by-default search panel opened from the header search action, matching the approved Tools menu reference.
- Kept the two-column 18-destination card grid and existing screen routes.
- Kept the brand header and bottom navigation; hid the tagline on the Tools screen to match the reference.
- Added accessible search toggle state, Escape-to-close, focus restoration, and clear-on-close behavior.
- Added a dedicated v98.44 CSS layer and included it in Android web bundle generation.
- Bumped Service Worker cache identity to prevent stale Tools UI.
- Preserved calculation engines and existing tool screen IDs.
