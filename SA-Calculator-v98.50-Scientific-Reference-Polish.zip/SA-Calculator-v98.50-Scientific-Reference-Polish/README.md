# SA Calculator v98.50 — Scientific Calculator Reference Polish

SA Calculator source release with the screenshot-led scientific keypad and basic-keypad refinement.

## Main updates
- Scientific Calculator uses a pale green expression/result display, graphite beveled keys, gold secondary legends and a 6-column function bank.
- Dedicated editing strip, SHIFT alternate mappings, DEG/RAD toggle, memory row, history and More controls remain connected to their existing handlers.
- Numeric/operator keypad is five columns by four rows.
- Basic calculator keypad spacing and visual weight are refined without reducing its minimum 48px touch target.
- Existing tool navigation and converter selection behavior are retained.

## Build and test
- `npm test`
- `npm run build:web`
- Android APK build is performed by the included GitHub Actions workflow.

## Release identity
- Package version: `1.98.50-v98.50`
- Android versionCode: `1098050`
- Workflow: `SA-Calculator-v98.50-Android-Workflow.yml`

## Validation boundary
Automated tests, JavaScript syntax, YAML parsing, ZIP integrity and web-bundle generation were verified locally. Android SDK/Gradle hosted build and physical-device visual/touch validation still need to run on the Android build runner and a real device.
