# Scientific Calculator benchmark — v98.47

## Benchmarked product patterns

This release was checked against current official help/product descriptions for GeoGebra Scientific Calculator, HiPER Scientific Calculator, Desmos Scientific Calculator and CalcTastic, plus current Android Play listings for other scientific calculators.

| Product/reference | Observed baseline or advanced pattern |
|---|---|
| GeoGebra Scientific Calculator | Fractions, trigonometry, statistics, exponential functions and logarithms |
| HiPER Scientific Calculator | Responsive layouts, fractions, equations, matrices/vectors, statistics, complex numbers, graphing, memory and history |
| Desmos Scientific Calculator | Arithmetic, exponentiation, radicals, absolute value, logarithms, rounding and percentages; streamlined scientific workflow |
| CalcTastic | Algebraic/RPN modes, history, multiple memory registers, trig in DEG/RAD/GRAD, hyperbolic functions, fractions, constants and statistics |
| Recent Android scientific calculator listings | DEG/RAD, inverse trig, eˣ/10ˣ, roots, factorial, memory, history and ANS are recurring user-facing functions |

## v98.47 implemented baseline

- Dedicated Scientific Calculator screen, separate from the Basic Calculator.
- Own expression editor and result output.
- DEG/RAD angle selector stored independently.
- π and Euler's e constants.
- xʸ, x², x³, square root, cube root, eˣ and 10ˣ.
- Absolute value, reciprocal and factorial.
- log10, ln and log2.
- sin/cos/tan, inverse trig, sinh/cosh/tanh.
- Own numeric/operator keypad, AC, delete, brackets, decimal and double-zero.
- ANS recall.
- MC, MR, M+, M− and MS memory actions with independent persistence.
- Independent last-50 calculation history, tap-to-restore and clear.

## Explicitly not claimed in this release

Fractions/mixed numbers, arbitrary precision, symbolic algebra, equations, graphing, matrices/vectors, complex arithmetic, statistical distributions, RPN, GRAD angle mode, and large physical-constant libraries are not implemented as working Scientific Calculator features in this release. They have not been represented with fake buttons or placeholder destinations.
