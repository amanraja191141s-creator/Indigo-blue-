const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const read = file => fs.readFileSync(path.join(root, file), 'utf8');

test('v98.24 keeps the reference UI and applies bounded dynamic viewport sizing', () => {
  const css = read('assets/css/app.css');
  assert.match(css, /v98\.24 — SCREEN OPTIMIZATION \/ ANDROID WEBVIEW HARDENING/);
  assert.match(css, /height:100dvh !important/);
  assert.match(css, /min-height:0 !important/);
  assert.match(css, /overscroll-behavior-y:contain !important/);
  assert.match(css, /@media \(max-width:340px\)/);
  assert.match(css, /@media \(max-height:560px\) and \(orientation:landscape\)/);
  assert.match(css, /prefers-reduced-motion:reduce/);
});

test('all 18 reference destinations remain present and their bottom navigation remains available', () => {
  const html = read('index.html');
  const expected = ['calc','currencies','units','discount','percent','salestax','bodymetrics','date','fuelcost','fuelefficiency','gradeavg','hex','loan','savings','tip','unitprice','worldtime','settings'];
  for (const id of expected) assert.match(html, new RegExp(`id="screen-${id}"`), `missing screen ${id}`);
  assert.match(html, /id="screen-favorites"/);
  for (const tab of ['calc','history','favorites','tools']) assert.match(html, new RegExp(`data-bottom-nav="${tab}"`));
  assert.match(html, /id="screen-settings"/);
});

test('Android WebView viewport metadata requests content resize when the keyboard opens', () => {
  assert.match(read('index.html'), /interactive-widget=resizes-content/);
});

test('v98.24 release identity matches the PWA, runtime, HTML and cache', () => {
  const pkg = JSON.parse(read('package.json'));
  const manifest = JSON.parse(read('manifest.webmanifest'));
  assert.equal(pkg.version, '1.98.50-v98.50');
  assert.equal(manifest.version, pkg.version);
  assert.match(read('assets/js/app.js'), new RegExp(`APP_VERSION = '${pkg.version.replaceAll('.', '\\.')}'`));
  assert.match(read('index.html'), new RegExp(`sa-build-version" content="${pkg.version.replaceAll('.', '\\.')}`));
  assert.match(read('service-worker.js'), /sa-calculator-v98-49-ui-correction-v9850/);
});
